# Dimension Estimation

[← Back to methodology](classification-framework.md) · [← Back to overview](../README.md)

This document explains how vessel dimensions are estimated from overhead imagery.

## Length

Measured from bow extremity to stern extremity, along the vessel's centerline axis, using a distance-scaled reference overlay applied to the image.

## Beam

Maximum vessel width, measured perpendicular to the centerline axis at the widest point of the hull — typically amidships.

## L/B Ratio

```
L/B = Length ÷ Beam
```

The length-to-beam ratio is a useful sanity check against classification. Different vessel classes tend to cluster around characteristic L/B ranges:

| Vessel Class | Typical L/B Range |
|---|---|
| Crude Oil Tanker | ~5.5 – 6.5 |
| LPG / LNG Carrier | ~6.0 – 7.0 |
| Container Vessel | ~6.5 – 8.0 |
| Bulk Carrier | ~5.5 – 6.5 |

An estimated L/B ratio that falls well outside the expected range for a proposed classification is treated as a flag to revisit the classification — not as a hard rule, but as a prompt to re-examine the structural evidence.

## Sources of Error

- Vessel orientation relative to the sensor (off-axis views compress apparent length)
- Image resolution and pixel-to-distance calibration
- Partial occlusion (cloud cover, adjacent vessels, port infrastructure)

Where these factors are material, Classification Confidence is adjusted downward accordingly — see [confidence-framework.md](confidence-framework.md).
