# Analytical Methodology

[← Back to overview](../README.md)

This document sets out the analytical framework applied across every case study in this portfolio. It exists so the main README can stay readable while the reasoning behind each classification remains fully auditable here.

The framework has five stages:

## A. Observation

**What is actually visible?**

Every assessment begins with a plain inventory of observable structure: hull outline, deck configuration, superstructure position, visible equipment (cranes, piping, tanks), and any cargo already loaded. No inference is made at this stage — only what is directly visible in the imagery is recorded.

## B. Measurement

**How was length/beam estimated?**

See [dimension-estimation.md](dimension-estimation.md) for the full method. In short, length and beam are estimated from bow/stern and port/starboard extremities using a reference-scaled overlay, and cross-checked for proportional plausibility against known vessel classes.

## C. Classification

**Which features discriminate between classes?**

Observed structural features are compared against the expected profile of each vessel class (tanker, LPG/LNG carrier, container vessel, bulk carrier, etc.). Classification is driven by convergence: the more independent features that point to the same class, the stronger the classification. See [evidence-vs-inference.md](evidence-vs-inference.md) for how evidence is separated from interpretation.

## D. Validation

**What external information was used?**

Where available, AIS transponder data, vessel registries, or known vessel particulars are used to cross-reference the visual classification. In the absence of such data, classification stands on visual evidence alone and Identity Confidence is marked `N/A` rather than guessed.

## E. Confidence

**How strong is the evidence?**

Confidence is assessed separately for detection, classification, and identity. See [confidence-framework.md](confidence-framework.md) for the three-tier scale and what each level means in practice.

<br>

---

### Related documents

- [Dimension Estimation](dimension-estimation.md)
- [Confidence Framework](confidence-framework.md)
- [Evidence vs. Inference](evidence-vs-inference.md)
