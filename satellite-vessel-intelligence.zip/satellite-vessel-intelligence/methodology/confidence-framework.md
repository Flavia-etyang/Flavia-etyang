# Confidence Framework

[← Back to methodology](classification-framework.md) · [← Back to overview](../README.md)

Three confidence levels are used across this portfolio, applied independently to **detection**, **classification**, and **identity**.

| Level | Meaning |
|---|---|
| `HIGH` | Multiple independent visual characteristics support the classification. |
| `MEDIUM` | The classification is supported, but image quality or vessel orientation limits certainty. |
| `LOW` | Available evidence is insufficient or conflicting. |

## The Important Distinction

Confidence refers to the strength of the evidence supporting the classification, not the certainty of vessel identity.

A classification can be rated `HIGH` confidence — meaning the structural evidence strongly and consistently points to "crude oil tanker" — while Identity Confidence remains `N/A`, because no AIS, registry, or named-vessel cross-reference exists for that image. The two are independent axes:

- **Classification confidence** asks: *how strong is the structural evidence for this vessel class?*
- **Identity confidence** asks: *how strong is the evidence for which specific, named vessel this is?*

Conflating the two overstates certainty. A vessel can be confidently classified as a container ship while remaining entirely unidentified.

## Applying the Framework

When assessing confidence, ask:

1. How many independent structural features support this classification?
2. Do any observed features conflict with the proposed classification?
3. Is image quality, resolution, or vessel orientation limiting what can be seen?
4. Is there external data (AIS, registry) available to validate — and does it agree?

A classification with four converging, non-conflicting features and clear imagery is `HIGH`. A classification with one or two supporting features, or with imagery constraints, is `MEDIUM`. A classification resting on ambiguous or contradictory evidence is `LOW`.
