# Evidence vs. Inference

[← Back to methodology](classification-framework.md) · [← Back to overview](../README.md)

A recurring discipline in this portfolio is keeping **observed evidence** clearly separated from **analytical inference** built on top of it.

## Evidence

Evidence is what is directly observable in the imagery: a line of piping on a deck, a set of raised cylindrical structures, a cluster of cranes, a repeating rectangular pattern of cargo blocks, the relative position of a superstructure. Evidence statements should be verifiable by any analyst looking at the same image — they don't require accepting a conclusion first.

*Example — evidence:* "Longitudinal piping is visible across the cargo deck."

## Inference

Inference is the conclusion drawn from combining pieces of evidence: that the piping, together with a clear deck and aft superstructure, supports a tanker classification. Inference is where analytical judgment enters, and it is only as strong as the evidence it converges on.

*Example — inference:* "This convergence of features supports classification as a crude oil tanker."

## Why the Separation Matters

Keeping these separate does two things:

1. **It makes the reasoning auditable.** Anyone reviewing a case study can check whether the stated evidence actually supports the stated conclusion, rather than having to take the conclusion on trust.
2. **It prevents evidence-shopping.** When evidence and inference are written down separately, it becomes obvious if a classification is being supported by only one weak feature dressed up as several restated conclusions.

Every case study in this portfolio is structured to state evidence first (the numbered callouts) and inference second (the classification assessment) — deliberately, and in that order.
