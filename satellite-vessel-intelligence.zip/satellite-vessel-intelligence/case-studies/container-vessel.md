# CASE 03 — Container Vessel

[← Back to overview](../README.md)

<table>
<tr>
<td align="center" width="33%"><img src="../assets/vessel-03-container/eo.png" width="100%"><br><sub>EO</sub></td>
<td align="center" width="33%"><img src="../assets/vessel-03-container/measurement-overlay.png" width="100%"><br><sub>Measurement overlay</sub></td>
<td align="center" width="33%"><img src="../assets/vessel-03-container/annotated-features.png" width="100%"><br><sub>Annotated features</sub></td>
</tr>
</table>

## Vessel Intelligence

| Field | Value |
|---|---|
| Broad Type | Merchant Vessel |
| Classification | Container Vessel |
| Estimated Length | 210.0 m |
| Estimated Beam | 30.0 m |
| L/B Ratio | 7.00 |
| Detection Confidence | `HIGH` |
| Classification Confidence | `HIGH` |
| Identity Confidence | N/A |

## Evidence

**01 — Container stacks**
Regular rectangular cargo blocks.

**02 — Cargo cranes**
Where visible, cranes provide additional classification evidence.

**03 — Cellular arrangement**
Repeated container geometry across the cargo deck distinguishes the vessel from bulk and liquid cargo vessels.

**Classification:** Container Vessel
**Confidence:** `HIGH`

## Confidence Rationale

The regularity and repetition of the container stack geometry is the strongest discriminator in this dataset — it is difficult to confuse with tanker or bulk carrier deck arrangements, which lack the cellular, gridded structure visible here.
