# CASE 02 — LPG Carrier

[← Back to overview](../README.md)

## When deck geometry changes the classification

<table>
<tr>
<td align="center" width="33%"><img src="../assets/vessel-02-lpg/eo.png" width="100%"><br><sub>EO</sub></td>
<td align="center" width="33%"><img src="../assets/vessel-02-lpg/measurement-overlay.png" width="100%"><br><sub>Measurement overlay</sub></td>
<td align="center" width="33%"><img src="../assets/vessel-02-lpg/annotated-features.png" width="100%"><br><sub>Annotated features</sub></td>
</tr>
</table>

## Vessel Intelligence

| Field | Value |
|---|---|
| Broad Type | Merchant Vessel |
| Classification | LPG Carrier |
| Estimated Length | 145.0 m |
| Estimated Beam | 22.8 m |
| L/B Ratio | 6.36 |
| Detection Confidence | `HIGH` |
| Classification Confidence | `HIGH` |
| Identity Confidence | N/A |

## Observable Indicators

- Cylindrical/spherical cargo containment structures
- Specialized deck equipment
- Distinctive cargo arrangement
- Different deck profile from conventional oil tankers

**Classification:** LPG Carrier
**Confidence:** `HIGH`

## The Key Insight

Not every tanker-like vessel with a relatively clear deck is an oil tanker. Cargo containment architecture becomes an important discriminator.

Where a crude oil tanker presents flush deck piping over an otherwise unobstructed cargo deck, an LPG carrier introduces raised, geometric containment structures — spherical or cylindrical tanks — that sit proud of the deck line. This single structural difference is often sufficient to separate the two classes even before hull proportions are considered.

## Confidence Rationale

Classification confidence is rated `HIGH` on the strength of the containment geometry alone, corroborated by deck equipment layout and overall cargo arrangement.
