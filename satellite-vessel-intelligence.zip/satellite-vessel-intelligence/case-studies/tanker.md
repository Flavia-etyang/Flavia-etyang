# CASE 01 — Crude Oil Tanker

[← Back to overview](../README.md)

<br>

## Imagery

<table>
<tr>
<td align="center" width="25%"><img src="../assets/vessel-01-tanker/eo.png" width="100%"><br><sub>EO</sub></td>
<td align="center" width="25%"><img src="../assets/vessel-01-tanker/sar.png" width="100%"><br><sub>SAR</sub></td>
<td align="center" width="25%"><img src="../assets/vessel-01-tanker/measurement-overlay.png" width="100%"><br><sub>Measurement overlay</sub></td>
<td align="center" width="25%"><img src="../assets/vessel-01-tanker/annotated-features.png" width="100%"><br><sub>Annotated features</sub></td>
</tr>
</table>

## Vessel Intelligence

| Field | Value |
|---|---|
| Broad Type | Merchant Vessel |
| Classification | Crude Oil Tanker |
| Estimated Length | 182.4 m |
| Estimated Beam | 32.1 m |
| L/B Ratio | 5.68 |
| Detection Confidence | `HIGH` |
| Classification Confidence | `HIGH` |
| Identity Confidence | N/A |

## Why a Tanker?

**01 — Deck piping**
Extensive longitudinal piping is visible across the cargo deck, consistent with liquid-cargo transfer infrastructure.

**02 — Clear cargo deck**
The deck lacks the dense, repetitive cargo arrangement expected on container vessels.

**03 — Superstructure**
The position and configuration of the superstructure support the tanker hypothesis.

**04 — Hull proportions**
Overall vessel geometry is consistent with a large merchant tanker configuration.

## Classification Assessment

The convergence of deck piping, cargo-deck configuration, superstructure placement and hull proportions supports classification as a crude oil tanker.

## Confidence Rationale

Classification confidence is rated `HIGH` because four independent structural indicators — piping, deck clearance, superstructure position, and hull proportions — are mutually consistent and none conflict with the tanker hypothesis. Identity confidence remains `N/A` in the absence of AIS or registry cross-reference for this sample.
