# Maritime Intelligence Portfolio

## Flavian Etyang
### Maritime Intelligence & Vessel Data Analyst

> **I specialize in transforming fragmented maritime data and satellite imagery into verified vessel intelligence.**

Four years of experience across vessel ownership intelligence, ocean-freight visibility, maritime compliance, vessel behavior, AIS analysis, satellite vessel tagging, vessel classification and vessel dimensions.

---

## What I Do

### Vessel Intelligence
Satellite Vessel Detection · Vessel Classification · Vessel Dimensions · Identity Resolution

### Maritime Intelligence
AIS Analysis · Vessel Tracking · Ownership Intelligence · Behavioral Analysis

### Risk & Compliance
Sanctions Screening · AIS/GNSS Anomalies · Deceptive Shipping · STS Intelligence

### Data & Analytics
Excel · Airtable · Power BI · SQL · Python · Geospatial Analysis

---

# Selected Intelligence Work

Five focused case studies demonstrate how I approach maritime intelligence problems.

| # | Case Study | Core Capability |
|---|---|---|
| 01 | [Satellite Vessel Intelligence](case-studies/01-satellite-vessel-intelligence.md) | Detect → Measure → Classify → Verify |
| 02 | [Vessel Ownership Intelligence](case-studies/02-vessel-ownership-intelligence.md) | Identity → Ownership → Control |
| 03 | [AIS Behavioral Intelligence](case-studies/03-ais-behavioral-intelligence.md) | Movement → Anomaly → Assessment |
| 04 | [Maritime Risk & Compliance](case-studies/04-maritime-risk-compliance.md) | Identity → Behavior → Risk |
| 05 | [STS Intelligence](case-studies/05-sts-intelligence.md) | Rendezvous → Evidence → Likelihood |

---

# How I Approach Maritime Intelligence

```text
Fragmented Maritime Signals
            ↓
      Data Validation
            ↓
      Entity Resolution
            ↓
   Vessel / Movement Analysis
            ↓
     Cross-Source Evidence
            ↓
   Confidence & Limitations
            ↓
     Intelligence Assessment
```

The objective is not simply to identify a vessel or find a data point.

It is to determine **what the available evidence supports, how confident that conclusion is, and what should be investigated next.**

---

# Experience

### Maritime Data / Intelligence Analyst
**2024 — Present**

Experience across:

- Vessel ownership research
- Ocean freight visibility
- Vessel movement tracking
- Maritime compliance
- AIS/GNSS interference and vessel jamming analysis
- Satellite-based vessel tagging
- Vessel classification from overhead imagery
- Vessel dimension estimation
- Maritime data research and validation

### Professional Progression

**Ownership Intelligence → Ocean Freight Visibility → Compliance → Satellite Vessel Intelligence**

---

# Maritime Intelligence Stack

**Maritime data:** AIS · Vessel particulars · Ownership · Port calls · Movement history

**Imagery:** Satellite / EO vessel detection · Visual vessel analysis

**Research:** Equasis · IMO GISIS · LexisNexis · ShipSpotting · Public records

**Analytics:** Excel · Power BI · SQL · Python · Geospatial analysis

---

# Portfolio Principles

### Observation
What is directly visible or recorded?

### Inference
What does the evidence suggest?

### Validation
Can the conclusion be supported by an independent source?

### Assessment
What conclusion is justified?

### Confidence
How certain is the conclusion?

This separation is deliberate. **A hypothesis is not presented as a fact.**

---

# Important Disclosure

This GitHub portfolio is an independent professional demonstration.

It does **not** disclose proprietary employer datasets, confidential client information, internal tooling, restricted workflows, screenshots, or non-public methodologies.

Where real-world investigations are included, sources and licensing should be documented and respected.

---

## Target Professional Positioning

> **Maritime Intelligence & Vessel Data Analyst**

**Specialization:** Vessel Intelligence · AIS · Satellite Vessel Detection · Ownership · Maritime Risk & Compliance · Behavioral Analysis

---

## Contact

**LinkedIn:** Add profile URL  
**Email:** Add professional email  
**CV:** Add CV link
