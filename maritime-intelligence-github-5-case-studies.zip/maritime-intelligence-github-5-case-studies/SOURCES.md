# Reference Sources

The portfolio is designed around capabilities currently emphasized by leading maritime-intelligence platforms.

- Kpler — maritime intelligence, AIS, vessel particulars, ownership, risk & compliance.
- Kpler — AIS tracking and maritime data services.
- Kpler — risk & compliance, including STS, AIS gaps/spoofing and ownership risk.
- Windward — multi-source maritime intelligence and behavioral analysis.
- Windward — vessel screening, seven-level ownership analysis and deceptive-shipping detection.
- Windward — remote sensing combining EO, SAR and RF with AIS, ownership and behavioral intelligence.

## Portfolio data rule

Use public or appropriately licensed data for independent case studies. Do not publish confidential employer information, proprietary datasets, internal screenshots or restricted methodologies.

Every actual case study should list the specific sources used and distinguish observation from inference.
