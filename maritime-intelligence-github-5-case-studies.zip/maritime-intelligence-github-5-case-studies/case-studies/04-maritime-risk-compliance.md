# 04 — Maritime Risk & Compliance

## Identity → Ownership → Behavior → Risk

### Intelligence Question

**What is the vessel's risk profile when identity, ownership, behavior and compliance indicators are evaluated together?**

### Investigation Framework

```text
Vessel Identity
      ↓
Ownership Structure
      ↓
Flag / Management
      ↓
AIS Behaviour
      ↓
STS / Other Activity
      ↓
Sanctions / Compliance
      ↓
Risk Assessment
```

### Risk Categories

| Risk Area | Assessment |
|---|---|
| Identity | [Low / Medium / High] |
| Ownership | [Low / Medium / High] |
| Flag | [Low / Medium / High] |
| AIS behavior | [Low / Medium / High] |
| STS activity | [Low / Medium / High] |
| Sanctions | [Low / Medium / High] |
| Overall | **[Assessment]** |

### Evidence

The assessment should distinguish between:

**Verified facts**  
What authoritative/public records establish.

**Behavioral indicators**  
What movement data suggests.

**Risk indicators**  
What warrants enhanced due diligence.

**Unresolved questions**  
What cannot yet be established.

### Intelligence Assessment

> **[Insert concise go / enhanced-due-diligence / investigate-further conclusion.]**

### Why It Matters

Modern maritime compliance increasingly requires more than static list screening. Risk can emerge through changing ownership, vessel behavior, AIS manipulation, STS activity and other contextual signals.

### Skills Demonstrated

`Maritime compliance` `Sanctions research` `Ownership intelligence` `AIS analysis` `Risk assessment`

### Evidence to Add

- Risk matrix
- Ownership snapshot
- AIS timeline
- Sanctions/source check
- Final risk assessment
