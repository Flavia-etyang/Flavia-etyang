# 01 — Satellite Vessel Intelligence

## Detect → Measure → Classify → Verify

### Intelligence Question

**How much reliable vessel intelligence can be extracted from overhead imagery before conventional vessel records are introduced?**

### What I Analyze

- Vessel detection
- Hull and deck geometry
- Bridge / superstructure
- Cranes and deck equipment
- Mast configuration
- Bow and stern characteristics
- Estimated LOA and beam
- Length-to-beam ratio
- Vessel class and subclass
- Candidate identity

### Analytical Workflow

```text
Satellite Detection
       ↓
Visual Feature Extraction
       ↓
Dimension Estimation
       ↓
Vessel Classification
       ↓
Candidate Matching
       ↓
AIS / Particulars Validation
       ↓
Confidence Assessment
```

### Example Output

| Attribute | Assessment |
|---|---|
| Broad type | Merchant vessel |
| Vessel class | [Analyst finding] |
| Subclass | [Analyst finding] |
| Estimated LOA | [XX m] |
| Estimated beam | [XX m] |
| Identity | [Candidate / unidentified] |
| Classification confidence | [XX%] |
| Identity confidence | [XX%] |

### Evidence

The assessment should explicitly reference observable characteristics such as:

**Deck structure · bridge position · cranes · mast · hull proportions · bow/stern geometry · superstructure**

### Intelligence Assessment

> **[Insert concise conclusion based on the actual image and supporting evidence.]**

### Why It Matters

Satellite detections become significantly more valuable when visual characteristics are converted into structured vessel intelligence and then correlated with AIS, vessel particulars and identity records.

### Skills Demonstrated

`Satellite imagery` `Vessel classification` `Dimension estimation` `Visual intelligence` `Entity resolution` `Confidence assessment`

### Evidence to Add

- Annotated satellite image
- Measurement overlay
- Vessel feature callouts
- Classification evidence card
- Optional AIS correlation map

> **Portfolio rule:** Do not invent an exact identity or measurement when the imagery cannot support it. State uncertainty.
