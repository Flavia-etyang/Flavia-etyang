# 02 — Vessel Ownership Intelligence

## Identity → Ownership → Control → Operation

### Intelligence Question

**Who legally owns the vessel, who controls the relevant entities, and who is responsible for its management and operation?**

### Ownership Framework

```text
Ultimate Beneficial Owner
          ↓
Beneficial / Holding Entity
          ↓
Registered Owner
          ↓
Technical Manager
          ↓
ISM Manager
          ↓
Commercial Manager
          ↓
Operator
          ↓
Vessel
```

### Investigation Scope

- IMO / MMSI identity
- Registered owner
- Beneficial owner / UBO
- Technical manager
- ISM manager
- Commercial manager
- Operator
- Historical vessel names
- Flag history
- Ownership changes
- Management changes
- Corporate relationships

### Research Sources

**Equasis · IMO GISIS · LexisNexis · ShipSpotting · Public corporate records**

### Example Output

| Relationship | Entity | Evidence |
|---|---|---|
| Vessel | [Vessel name / IMO] | [Source] |
| Registered owner | [Entity] | [Source] |
| Beneficial owner | [Entity] | [Source] |
| Technical manager | [Entity] | [Source] |
| ISM manager | [Entity] | [Source] |
| Commercial manager | [Entity] | [Source] |
| Operator | [Entity] | [Source] |

### Ownership Timeline

```text
[Year] ── Owner A
           ↓
[Year] ── Owner B
           ↓
[Year] ── Flag change
           ↓
[Year] ── Manager change
```

### Intelligence Assessment

> **[Insert concise conclusion explaining the ownership structure, changes and any material ambiguity.]**

### Why It Matters

Ownership intelligence underpins vessel authentication, counterparty due diligence, sanctions screening, insurance decisions and maritime risk assessment.

### Skills Demonstrated

`Ownership intelligence` `Entity resolution` `Corporate research` `Vessel history` `Due diligence`

### Evidence to Add

- Ownership relationship diagram
- Timeline of changes
- Source table
- Entity-resolution notes
