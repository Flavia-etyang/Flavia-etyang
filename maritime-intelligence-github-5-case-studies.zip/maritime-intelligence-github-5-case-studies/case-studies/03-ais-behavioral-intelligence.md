# 03 — AIS Behavioral Intelligence

## Movement → Anomaly → Context → Assessment

### Intelligence Question

**Does a vessel's observed behavior differ materially from its expected or historical pattern?**

### Behavioral Indicators

- AIS gaps
- Speed anomalies
- Course deviations
- Unexpected destinations
- Loitering
- Unusual anchorage behavior
- Repeated rendezvous
- Changes in movement pattern
- Potential location / identity manipulation

### Analytical Workflow

```text
AIS Track
   ↓
Historical Baseline
   ↓
Movement Anomaly
   ↓
Contextual Checks
   ↓
Alternative Explanations
   ↓
Risk / Investigation Priority
```

### Example Output

| Indicator | Finding |
|---|---|
| AIS gap | [XX hours] |
| Route deviation | [XX NM] |
| Speed anomaly | [Finding] |
| Loitering | [Finding] |
| Historical comparison | [Finding] |
| Investigation priority | [Low / Medium / High] |

### Analytical Discipline

An AIS gap is **not automatically proof of deliberate concealment**.

Possible explanations should include:

- Coverage limitations
- Equipment failure
- Transmission issues
- GNSS interference
- Data-processing limitations
- Intentional AIS manipulation

### Intelligence Assessment

> **[Insert concise assessment explaining the observed behavior and why it is or is not anomalous.]**

### Why It Matters

Behavioral analysis turns vessel positions into contextual intelligence. The key question moves from **“Where is the vessel?”** to **“Is the vessel behaving as expected?”**

### Skills Demonstrated

`AIS` `Movement analysis` `Behavioral intelligence` `Anomaly analysis` `Maritime context`

### Evidence to Add

- AIS track map
- Timeline
- Anomaly callout
- Historical comparison
- Confidence / investigation-priority indicator
