# 05 — Ship-to-Ship Transfer Intelligence

## Rendezvous → Evidence → Likelihood

### Intelligence Question

**Is the observed interaction between two vessels consistent with a ship-to-ship transfer?**

### Core Indicators

**1. Proximity**  
Are the vessels within a plausible transfer distance?

**2. Speed**  
Do both vessels slow or maintain compatible movement?

**3. Heading / geometry**  
Do the vessels exhibit coordinated or parallel movement?

**4. Duration**  
Is the interaction sustained long enough to be meaningful?

**5. Location**  
Does the location provide operational context?

**6. AIS behavior**  
Are there gaps, inconsistencies or unusual reporting patterns?

**7. Subsequent movement**  
Do the vessels separate toward different destinations?

### Analytical Workflow

```text
Vessel A Track
      +
Vessel B Track
      ↓
Proximity Analysis
      ↓
Speed / Heading Analysis
      ↓
Duration
      ↓
Location Context
      ↓
AIS Integrity Check
      ↓
STS Likelihood
```

### Example Output

| Indicator | Finding |
|---|---|
| Minimum separation | [XX NM] |
| Duration | [XX hours] |
| Speed profile | [Finding] |
| Heading relationship | [Finding] |
| AIS continuity | [Finding] |
| Location | [Finding] |
| Subsequent destinations | [Finding] |
| STS likelihood | **[Low / Medium / High]** |

### Analytical Principle

A single indicator does not establish an STS transfer.

Confidence increases when **multiple independent indicators converge**.

> **Assessment ≠ proof.**

### Intelligence Assessment

> **[Insert concise conclusion explaining whether the observed behavior is consistent with an STS operation and why.]**

### Why It Matters

STS analysis can support investigations involving cargo movements, sanctions exposure, deceptive shipping, dark-fleet activity and maritime risk.

### Skills Demonstrated

`AIS` `Behavioral analysis` `STS intelligence` `Geospatial reasoning` `Risk assessment`

### Evidence to Add

- Dual-vessel AIS track
- Proximity timeline
- Speed chart
- Satellite confirmation where available
- Final STS likelihood score
