# Case Study Template

## Intelligence Question

One sentence.

## Evidence

Only the most relevant evidence.

## Method

3–6 analytical steps.

## Findings

A compact table.

## Intelligence Assessment

2–4 sentences.

## Confidence

Low / Medium / High, with reason.

## Why It Matters

One short paragraph.

## Skills Demonstrated

5–8 tags.

## Evidence to Add

Images, maps, timelines, data or notebooks.
